#include <stdio.h>

void unlock()

{
	puts("Passou\n");
}
